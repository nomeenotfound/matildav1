import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCollection } from '../context/CollectionContext';
import { X, ShoppingBag, ArrowRight, Trash2 } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateQuantity,
    cartTotal,
    triggerCheckoutHandoff,
  } = useCollection();

  if (!isCartOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex justify-end">
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsCartOpen(false)}
          className="absolute inset-0 bg-black/40 backdrop-blur-md"
        />

        {/* Drawer Container */}
        <motion.div
          initial={{ x: '100%' }}
          animate={{ x: 0 }}
          exit={{ x: '100%' }}
          transition={{ type: 'spring', damping: 26, stiffness: 220 }}
          className="relative z-10 w-full sm:w-[420px] h-full bg-[var(--bg-primary)]/85 backdrop-blur-xl text-[var(--text-primary)] border-l border-[var(--border-main)]/20 shadow-2xl flex flex-col justify-between p-6 overflow-hidden"
        >
          {/* Header */}
          <div className="flex items-center justify-between pb-2">
            <div>
              <h2 className="font-display text-base font-bold lowercase tracking-tight text-[var(--text-dominant)] flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[var(--border-maroon)]" />
                shopping bag ({cart.reduce((a, b) => a + b.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="w-8 h-8 rounded-full bg-[var(--bg-primary)]/60 backdrop-blur-md flex items-center justify-center text-[var(--text-dominant)] hover:bg-[var(--border-maroon)] hover:text-white transition-all text-xs"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto py-4 space-y-3">
            {cart.length === 0 ? (
              <div className="text-center py-20 text-xs text-[var(--text-muted)] space-y-2">
                <p className="font-display text-xs font-bold lowercase text-[var(--text-dominant)]">your bag is empty.</p>
                <p className="text-xs lowercase">add simple clothes or solid silver to start.</p>
              </div>
            ) : (
              cart.map((item) => (
                <div
                  key={`${item.product.id}-${item.selectedVariant.id}`}
                  className="flex items-center justify-between gap-3 rounded-2xl bg-[var(--bg-primary)]/60 backdrop-blur-md border border-[var(--border-main)]/20 p-3.5 shadow-xs"
                >
                  <div className="w-16 h-16 aspect-square rounded-xl overflow-hidden bg-[var(--card-inner)]/60 shrink-0">
                    <img
                      src={item.product.mainImage}
                      alt={item.product.title}
                      className="w-full h-full aspect-square object-cover"
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-between h-full text-xs">
                    <div>
                      <div className="flex justify-between items-start gap-1">
                        <h4 className="font-display text-xs font-bold lowercase truncate text-[var(--text-dominant)]">
                          {item.product.title}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.product.id, item.selectedVariant.id)}
                          className="text-[var(--text-muted)] hover:text-red-500 font-bold p-0.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <span className="inline-block px-2.5 py-0.5 text-[10px] mt-1 bg-[var(--bg-primary)]/80 text-[var(--border-maroon)] font-semibold rounded-full lowercase">
                        {item.selectedVariant.name}
                      </span>
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-2">
                      <div className="flex items-center gap-1 bg-[var(--bg-primary)]/90 px-2.5 py-0.5 rounded-full text-xs font-bold shadow-xs">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedVariant.id, -1)}
                          className="hover:text-[var(--border-maroon)] px-1"
                        >
                          -
                        </button>
                        <span className="px-1.5">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedVariant.id, 1)}
                          className="hover:text-[var(--border-maroon)] px-1"
                        >
                          +
                        </button>
                      </div>
                      <span className="font-bold text-[var(--text-dominant)]">₹ {(item.product.price * item.quantity).toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Bottom Total & Checkout Handoff */}
          <div className="pt-3 space-y-3 text-xs">
            <div className="flex justify-between items-center text-xs font-bold text-[var(--text-dominant)] pb-1 lowercase">
              <span>total value</span>
              <span className="text-sm font-extrabold text-[var(--border-maroon)]">₹ {cartTotal.toLocaleString('en-IN')}</span>
            </div>

            <p className="text-[11px] text-[var(--text-muted)] lowercase italic font-serif">
              free standard insured shipping across india included.
            </p>

            <button
              disabled={cart.length === 0}
              onClick={() => {
                setIsCartOpen(false);
                triggerCheckoutHandoff();
              }}
              className="w-full py-3.5 rounded-full bg-[var(--border-maroon)] text-white font-medium lowercase tracking-wide hover:bg-[var(--text-dominant)] disabled:opacity-40 disabled:cursor-not-allowed transition-all text-xs flex items-center justify-center gap-2 shadow-sm active:scale-[0.98]"
            >
              <span>proceed to checkout</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

